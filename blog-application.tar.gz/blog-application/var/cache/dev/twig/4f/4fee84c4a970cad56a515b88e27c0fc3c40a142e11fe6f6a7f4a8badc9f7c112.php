<?php

/* blog/index.html.twig */
class __TwigTemplate_fc0c4e200a7e783467bc5050cc8e9e3391ca760f70962a699b89165da5a44822 extends Twig_Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "blog/index.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "blog/index.html.twig"));

        // line 1
        echo "<link href=\"//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css\" rel=\"stylesheet\" id=\"bootstrap-css\">
<script src=\"//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js\"></script>
<script src=\"//code.jquery.com/jquery-1.11.1.min.js\"></script>
<!------ Include the above in your HEAD tag ---------->
<style>

    body {
        padding-top: 20px;
        padding-bottom: 20px;
    }

    /* Everything but the jumbotron gets side spacing for mobile first views */
    .header,
    .marketing,
    .footer {
        padding-right: 15px;
        padding-left: 15px;
    }

    /* Custom page header */
    .header {
        border-bottom: 1px solid #e5e5e5;
    }
    /* Make the masthead heading the same height as the navigation */
    .header h3 {
        padding-bottom: 19px;
        margin-top: 0;
        margin-bottom: 0;
        line-height: 40px;
    }

    /* Custom page footer */
    .footer {
        padding-top: 19px;
        color: #777;
        border-top: 1px solid #e5e5e5;
    }

    /* Customize container */
    @media (min-width: 768px) {
        .container {
            max-width: 730px;
        }
    }
    .container-narrow > hr {
        margin: 30px 0;
    }

    /* Main marketing message and sign up button */
    .jumbotron {
        text-align: center;
        border-bottom: 1px solid #e5e5e5;
    }
    .jumbotron .btn {
        padding: 14px 24px;
        font-size: 21px;
    }

    /* Supporting marketing content */
    .marketing {
        margin: 40px 0;
    }
    .marketing p + h4 {
        margin-top: 28px;
    }

    /* Responsive: Portrait tablets and up */
    @media screen and (min-width: 768px) {
        /* Remove the padding we set earlier */
        .header,
        .marketing,
        .footer {
            padding-right: 0;
            padding-left: 0;
        }
        /* Space out the masthead */
        .header {
            margin-bottom: 30px;
        }
        /* Remove the bottom border on the jumbotron for visual effect */
        .jumbotron {
            border-bottom: 0;
        }
    }
</style>

";
        // line 87
        echo         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 87, $this->source); })()), 'form_start', array("attr" => array("novalidate" => "novalidate")));
        echo "
";
        // line 88
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 88, $this->source); })()), 'widget');
        echo "
";
        // line 89
        echo         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 89, $this->source); })()), 'form_end');
        echo "
<div class=\"container\">
    <h1 class=\"well\">Registration Form</h1>
    <div class=\"col-lg-12 well\">
        <div class=\"row\">
            <form>
                <div class=\"col-sm-12\">
                    <div class=\"row\">
                        <div class=\"col-sm-6 form-group\">
                            <label>First Name</label>
                            <input type=\"text\" placeholder=\"Enter First Name Here..\" class=\"form-control\">
                        </div>
                        <div class=\"col-sm-6 form-group\">
                            <label>Last Name</label>
                            <input type=\"text\" placeholder=\"Enter Last Name Here..\" class=\"form-control\">
                        </div>
                    </div>
                    <div class=\"row\">
                        <div class=\"col-sm-6 form-group\">
                            <label>Title</label>
                            <input type=\"text\" placeholder=\"Enter Designation Here..\" class=\"form-control\">
                        </div>
                        <div class=\"col-sm-6 form-group\">
                            <label>Company</label>
                            <input type=\"text\" placeholder=\"Enter Company Name Here..\" class=\"form-control\">
                        </div>
                    </div>
                    <div class=\"form-group\">
                        <label>Phone Number</label>
                        <input type=\"text\" placeholder=\"Enter Phone Number Here..\" class=\"form-control\">
                    </div>
                    <div class=\"form-group\">
                        <label>Email Address</label>
                        <input type=\"text\" placeholder=\"Enter Email Address Here..\" class=\"form-control\">
                    </div>
                    <div class=\"form-group\">
                        <label>Website</label>
                        <input type=\"text\" placeholder=\"Enter Website Name Here..\" class=\"form-control\">
                    </div>
                    <div class=\"form-group\">
                        <label>Address</label>
                        <textarea placeholder=\"Enter Address Here..\" rows=\"3\" class=\"form-control\"></textarea>
                    </div>
                    <div class=\"row\">
                        <div class=\"col-sm-4 form-group\">
                            <label>City</label>
                            <input type=\"text\" placeholder=\"Enter City Name Here..\" class=\"form-control\">
                        </div>
                        <div class=\"col-sm-4 form-group\">
                            <label>State</label>
                            <input type=\"text\" placeholder=\"Enter State Name Here..\" class=\"form-control\">
                        </div>
                        <div class=\"col-sm-4 form-group\">
                            <label>Zip</label>
                            <input type=\"text\" placeholder=\"Enter Zip Code Here..\" class=\"form-control\">
                        </div>
                    </div>

                    <button type=\"button\" class=\"btn btn-lg btn-info\">Submit</button>
                </div>
            </form>
        </div>
    </div>
</div>";
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "blog/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  125 => 89,  121 => 88,  117 => 87,  29 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<link href=\"//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css\" rel=\"stylesheet\" id=\"bootstrap-css\">
<script src=\"//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js\"></script>
<script src=\"//code.jquery.com/jquery-1.11.1.min.js\"></script>
<!------ Include the above in your HEAD tag ---------->
<style>

    body {
        padding-top: 20px;
        padding-bottom: 20px;
    }

    /* Everything but the jumbotron gets side spacing for mobile first views */
    .header,
    .marketing,
    .footer {
        padding-right: 15px;
        padding-left: 15px;
    }

    /* Custom page header */
    .header {
        border-bottom: 1px solid #e5e5e5;
    }
    /* Make the masthead heading the same height as the navigation */
    .header h3 {
        padding-bottom: 19px;
        margin-top: 0;
        margin-bottom: 0;
        line-height: 40px;
    }

    /* Custom page footer */
    .footer {
        padding-top: 19px;
        color: #777;
        border-top: 1px solid #e5e5e5;
    }

    /* Customize container */
    @media (min-width: 768px) {
        .container {
            max-width: 730px;
        }
    }
    .container-narrow > hr {
        margin: 30px 0;
    }

    /* Main marketing message and sign up button */
    .jumbotron {
        text-align: center;
        border-bottom: 1px solid #e5e5e5;
    }
    .jumbotron .btn {
        padding: 14px 24px;
        font-size: 21px;
    }

    /* Supporting marketing content */
    .marketing {
        margin: 40px 0;
    }
    .marketing p + h4 {
        margin-top: 28px;
    }

    /* Responsive: Portrait tablets and up */
    @media screen and (min-width: 768px) {
        /* Remove the padding we set earlier */
        .header,
        .marketing,
        .footer {
            padding-right: 0;
            padding-left: 0;
        }
        /* Space out the masthead */
        .header {
            margin-bottom: 30px;
        }
        /* Remove the bottom border on the jumbotron for visual effect */
        .jumbotron {
            border-bottom: 0;
        }
    }
</style>

{{ form_start(form, {'attr': {'novalidate': 'novalidate'}}) }}
{{ form_widget(form) }}
{{ form_end(form) }}
<div class=\"container\">
    <h1 class=\"well\">Registration Form</h1>
    <div class=\"col-lg-12 well\">
        <div class=\"row\">
            <form>
                <div class=\"col-sm-12\">
                    <div class=\"row\">
                        <div class=\"col-sm-6 form-group\">
                            <label>First Name</label>
                            <input type=\"text\" placeholder=\"Enter First Name Here..\" class=\"form-control\">
                        </div>
                        <div class=\"col-sm-6 form-group\">
                            <label>Last Name</label>
                            <input type=\"text\" placeholder=\"Enter Last Name Here..\" class=\"form-control\">
                        </div>
                    </div>
                    <div class=\"row\">
                        <div class=\"col-sm-6 form-group\">
                            <label>Title</label>
                            <input type=\"text\" placeholder=\"Enter Designation Here..\" class=\"form-control\">
                        </div>
                        <div class=\"col-sm-6 form-group\">
                            <label>Company</label>
                            <input type=\"text\" placeholder=\"Enter Company Name Here..\" class=\"form-control\">
                        </div>
                    </div>
                    <div class=\"form-group\">
                        <label>Phone Number</label>
                        <input type=\"text\" placeholder=\"Enter Phone Number Here..\" class=\"form-control\">
                    </div>
                    <div class=\"form-group\">
                        <label>Email Address</label>
                        <input type=\"text\" placeholder=\"Enter Email Address Here..\" class=\"form-control\">
                    </div>
                    <div class=\"form-group\">
                        <label>Website</label>
                        <input type=\"text\" placeholder=\"Enter Website Name Here..\" class=\"form-control\">
                    </div>
                    <div class=\"form-group\">
                        <label>Address</label>
                        <textarea placeholder=\"Enter Address Here..\" rows=\"3\" class=\"form-control\"></textarea>
                    </div>
                    <div class=\"row\">
                        <div class=\"col-sm-4 form-group\">
                            <label>City</label>
                            <input type=\"text\" placeholder=\"Enter City Name Here..\" class=\"form-control\">
                        </div>
                        <div class=\"col-sm-4 form-group\">
                            <label>State</label>
                            <input type=\"text\" placeholder=\"Enter State Name Here..\" class=\"form-control\">
                        </div>
                        <div class=\"col-sm-4 form-group\">
                            <label>Zip</label>
                            <input type=\"text\" placeholder=\"Enter Zip Code Here..\" class=\"form-control\">
                        </div>
                    </div>

                    <button type=\"button\" class=\"btn btn-lg btn-info\">Submit</button>
                </div>
            </form>
        </div>
    </div>
</div>", "blog/index.html.twig", "/home/manoj/manoj/blog-application/templates/blog/index.html.twig");
    }
}
